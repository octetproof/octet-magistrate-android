// magistrate/BundleCache.kt
// The last-known-VALID bundle cache: an in-memory value with optional write-through
// to a persistent PolicyBundleStore. Factored out of Magistrate so the
// load-on-init + write-through behaviour is unit-testable without a started
// OctetSdk. Mirror of iOS BundleCache.
package com.octetproof.magistrate

internal class BundleCache(private val store: PolicyBundleStore?) {
    private val lock = Any()

    // Seeds the in-memory value from the store (cross-launch load). With no store,
    // the cache is in-memory only for the instance's lifetime.
    private var memory: PolicyBundleRecord? = store?.load()

    /** The current last-`VALID` record, or null if none has been adopted/restored. */
    fun current(): PolicyBundleRecord? = synchronized(lock) { memory }

    /**
     * Adopt a freshly-verified bundle: update memory and write through to the store.
     * The caller carries the anchor forward (`version ?: previous`) so a bundle
     * whose version can't be read never regresses the downgrade anchor.
     */
    fun adopt(record: PolicyBundleRecord) {
        synchronized(lock) { memory = record }
        store?.save(record)
    }
}

// magistrate/Magistrate.kt
// The Magistrate facade.
//
// Flow (app-driven; the decision itself stays server-authoritative):
//   1. Read the policy fields off the license: the bundle fetch URL + the Ed25519 trust roots.
//   2. Fetch the signed bundle from that URL.
//   3. verifyBundle(...) against the trust roots — FAIL-CLOSED (anything but
//      VALID throws).
//   4. proofPlan(...) reads the signed plan the bundle carries (area level +
//      disc shapes).
//   5. Mint one unbound area proof (proveArea, when level != none) and one
//      disc-bound verdict proof per shape (proveDiscVerdict).
// The host then submits the results (and the same decisionRef) to the policy
// service's POST /v1/decide, which makes the authoritative decision.
//
// decideMany(license, policies) runs the multi-policy variant (proof model v2):
// challenge the policy set, merge their plans, prove once against the merged plan,
// and get one decision per policy back.
package com.octetproof.magistrate

import com.octetproof.sdk.api.LatLon
import com.octetproof.sdk.api.LicenseStatus
import com.octetproof.sdk.api.OctetRegion
import com.octetproof.sdk.api.OctetSdk
import com.octetproof.sdk.api.OctetVerdict
import com.octetproof.sdk.api.OctetServiceRequest
import com.octetproof.sdk.api.PolicyTrustRoot
import com.octetproof.sdk.api.ProofRegion
import kotlinx.coroutines.CancellationException
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import uniffi.opl_ffi.BundleStatus
import uniffi.opl_ffi.PlanLevel
import uniffi.opl_ffi.ProofPlan
import uniffi.opl_ffi.ShapeRegion
import uniffi.opl_ffi.SlimException
import uniffi.opl_ffi.TrustRoot
import uniffi.opl_ffi.mergePlans
import uniffi.opl_ffi.proofPlan
import uniffi.opl_ffi.verifyBundle
import java.util.Base64

/** Outcome of the pure refresh decision — see [Magistrate.resolve]. */
internal enum class BundleResolution { ADOPT_FRESH, KEEP_CACHED, REJECT_FRESH, FETCH_FAILED }

class Magistrate internal constructor(
    private val sdk: OctetSdk,
    private val fetch: suspend (String) -> String,
    // Extract a bundle's monotonic version from its (already-verified) JSON, to
    // anchor the downgrade guard: passed back to verifyBundle as activeVersion
    // on the next refresh, so a validly-signed but older bundle is rejected as
    // STALE. The public constructors use bundleVersionFromContent (the signed
    // content.version); this parameter's default (null) leaves the downgrade check
    // off. Injected so the anchor is testable.
    private val bundleVersion: (String) -> ULong? = { null },
    // Cross-launch persistence for the last-VALID bundle + version anchor; null =
    // in-memory only (per-instance).
    store: PolicyBundleStore? = null,
    // JSON POST to the policy service (/v1/decide/challenge, /v1/decide): (url,
    // body) -> (HTTP status, body). Injected so tests run without a network.
    private val post: suspend (String, String) -> Pair<Int, String>,
) {
    /**
     * @param sdk a started [OctetSdk] (its `isWithin` mints the proofs). Caches the
     *   last-`VALID` bundle in memory only (per-instance).
     */
    constructor(sdk: OctetSdk) :
        this(sdk, serviceFetch(sdk), ::bundleVersionFromContent, null, servicePost(sdk))

    /**
     * @param sdk a started [OctetSdk].
     * @param persistentStore a rollback-resistant store (e.g.
     *   [EncryptedPrefsPolicyBundleStore]) so the last-`VALID` bundle + its version
     *   anchor survive relaunch.
     */
    constructor(sdk: OctetSdk, persistentStore: PolicyBundleStore) :
        this(sdk, serviceFetch(sdk), ::bundleVersionFromContent, persistentStore, servicePost(sdk))

    // Last-known-VALID bundle: fallback on a failed refresh + source of the
    // downgrade anchor. In-memory by default; backed by `store` when supplied.
    private val cache = BundleCache(store)

    private enum class BundleSource { FRESH, CACHED }
    private data class ActiveBundle(val json: String, val source: BundleSource)

    /**
     * Verify the tenant's active policy bundle and prove every region it
     * requires, all bound to [decisionRef].
     *
     * @param license the current [LicenseStatus] (pass `sdk.licenseStatus`); its
     *   The policy fields carry the bundle URL + trust roots.
     * @param decisionRef the host-minted decision correlation id (1…256 bytes),
     *   threaded into every proof so the uploads bind to this decision.
     * @throws PolicyException on any failure (fail-closed on an untrusted or
     *   unfetchable bundle, or an unsupported required region).
     */
    suspend fun evaluate(license: LicenseStatus, decisionRef: String): PolicyEvaluation {
        // 1–3. Refresh the bundle: fetch → verify (fail-closed) → cache, falling
        //       back to the last-known-VALID bundle when a refresh fails.
        val active = resolveActiveBundle(license)

        // 4. Read the signed proof plan (proof model v2). The active bundle is trusted,
        //    so map a reader error fail-closed (malformed / unsupported plan).
        val plan = readPlan(active.json)

        // 5. A decision-bound verdict per disc shape. The plan's country/subdivision
        //    `level` is the phone's own area claim (decided from the area proof), not a
        //    region to query here, so `evaluate` surfaces the geometric shapes only.
        val results = plan.shapes.mapNotNull { shape ->
            val disc = shape.region as? ShapeRegion.Disc ?: return@mapNotNull null
            val canonical = "disc:${disc.lat},${disc.lon},${disc.radiusM}"
            val region = OctetRegion.disc(LatLon(disc.lat, disc.lon), disc.radiusM)
            val verdict = sdk.loc.isWithin(region = region, decisionRef = decisionRef)
            PolicyRegionResult(canonical, region, verdict)
        }
        return PolicyEvaluation(results, servedFromCache = active.source == BundleSource.CACHED)
    }

    /**
     * Prove every region the tenant's active policy bundle requires, on device, for
     * the in-request `POST /v1/decide` path (E1b) — returning the signed
     * LocationProof envelopes bound to [nonce] instead of uploading them.
     *
     * Host flow: `POST /v1/decide/challenge` → `{decision_ref, nonce}` →
     * `prove(license, nonce)` → `POST /v1/decide` with the same `decision_ref` and
     * `proofs: [{proof_bytes_b64}]`. The engine runs the verifier over the bytes and
     * decides — server-authoritative.
     *
     * @param license the current [LicenseStatus] (its policy fields locate + trust the
     *   bundle); the bundle is verified + cached exactly as in [evaluate].
     * @param nonce the challenge nonce STRING from `/v1/decide/challenge`, verbatim.
     *   Its UTF-8 bytes are the session-binding nonce — it is **not** base64url
     *   decoded (the engine binds `nonce.as_bytes()`).
     * @return one [PolicyProof] per required region (a region that couldn't be
     *   proven has `proofBytes == null`).
     * @throws PolicyException fail-closed on an untrusted/unfetchable bundle, an
     *   unsupported region, or an invalid nonce.
     */
    suspend fun prove(license: LicenseStatus, nonce: String): List<PolicyProof> {
        val nonceBytes = sessionNonceBytes(nonce)
        val active = resolveActiveBundle(license)
        return proveRequired(active.json, nonceBytes)
    }

    /**
     * The device's attestation enrolment bundle for a server-submitted
     * `POST /v1/decide` (`attestation_enrolment`). Always null on Android: every proof
     * carries its hardware key attestation chain, so the engine needs no enrolment.
     *
     * It exists so a host can write the server-started flow once for both platforms:
     * send `attestationEnrolment()` along with the proofs from [prove], and pass it on
     * when it isn't null (on iOS it is the device's App Attest enrolment bundle).
     */
    fun attestationEnrolment(): String? = null

    /**
     * The `env` a `POST /v1/decide/challenge` must carry for this device's proofs, for
     * a host whose server starts the check (the server-started flow).
     *
     * An SDK signed in with a sandbox token uploads its proofs as sandbox, so the
     * engine must look for them there; the challenge without `env` reads prod, finds
     * none and answers UNKNOWN (`absence`). Send this to the server when the app asks
     * for a check, and have the server put it on the challenge as `env` when it isn't
     * null. [decide] and [decideMany] send it themselves.
     *
     * @return `"sandbox"` for a sandbox-token SDK, null for prod (send no `env`).
     */
    fun challengeEnv(license: LicenseStatus): String? = challengeEnvOf(license)

    /**
     * Ask the policy service for a decision, proving on device every region the
     * tenant's active bundle requires (the in-request path, E1b).
     *
     * Runs the whole handshake: `POST /v1/decide/challenge` → prove each required
     * region bound to the challenge nonce (as [prove]) → `POST /v1/decide` with the
     * signed proofs. The engine verifies the proofs and decides —
     * server-authoritative. The policy service is the origin of the license's
     * `policyBundleFetchUrl`; the policy name comes from the verified bundle, and
     * `license_id` from `license.licenseId`. On an SDK signed in with a sandbox
     * token, the challenge asks for the sandbox proofs (`env: sandbox`).
     *
     * @param license the current [LicenseStatus] (pass `sdk.licenseStatus`).
     * @param subjectId optional subject id, for policies that use subject attributes.
     * @param accountId optional tenant hint.
     * @return the engine's [DecisionResult]. A `deny` is a result, not an error. Its
     *   [DecisionResult.claimedArea] is the area the device disclosed in the submitted
     *   area proof (never coordinates), or null when no area proof was submitted.
     * @throws PolicyException fail-closed on an untrusted/unfetchable bundle, an
     *   unsupported region, no provable region, or a refused/failed request.
     */
    suspend fun decide(
        license: LicenseStatus,
        subjectId: String? = null,
        accountId: String? = null,
    ): DecisionResult {
        val licenseId = license.licenseId?.takeIf { it.isNotEmpty() }
            ?: throw PolicyException.LicenseIdUnavailable
        val engine = license.policyBundleFetchUrl?.let { engineOrigin(it) }
            ?: throw PolicyException.NotProvisioned
        val active = resolveActiveBundle(license)
        val policy = policyNameFromBundle(active.json)
            ?: throw PolicyException.BundleRejected(BundleRejection.MALFORMED)
        // The area the submitted area proof claims, read off the proof as it is minted.
        var claimedArea: ClaimedArea? = null
        val result = runDecide(engine, policy, licenseId, subjectId, accountId, post,
            env = challengeEnvOf(license)) { nonce ->
            val proofs = proveRequired(active.json, sessionNonceBytes(nonce))
            val submitted = proofs.mapNotNull { it.proofBytesBase64Url }
            // Say why nothing could be proven — the verdicts carry the reason.
            if (submitted.isEmpty()) {
                throw PolicyException.NoProofProduced(proofs.map {
                    "${it.canonical}: ${it.verdict.reason} — ${it.verdict.message}"
                })
            }
            claimedArea = claimedAreaOf(proofs)
            submitted
        }
        return result.copy(claimedArea = claimedArea)
    }

    /**
     * Ask the policy service for a decision on **several policies at once**: one
     * challenge, one set of on-device proofs, one decision per policy.
     *
     * Runs the multi-policy handshake: `POST /v1/decide/challenge` with the
     * [policies] names → fetch + verify each policy's bundle and read its plan →
     * `merge_plans` them → prove **once** against the merged plan (one unbound area
     * proof, skipped when the merged `level` is none, plus one disc-verdict proof per
     * merged shape), bound to the challenge nonce → `POST /v1/decide` with the same
     * challenge set and the unlabelled proofs. The engine sorts the proofs, verifies
     * each once, and decides every policy independently — server-authoritative. A
     * `deny` (for any policy) is a result, not an error.
     *
     * @param license the current [LicenseStatus] (pass `sdk.licenseStatus`); its policy
     *   fields locate + trust the bundles. Each policy's bundle is fetched from the
     *   license's `policyBundleFetchUrl` with the `policy` query parameter set to the
     *   policy name.
     * @param policies the policy names to decide together — 1…16, matching the
     *   engine's per-check maximum. The same set is echoed on `/v1/decide`, so a
     *   concurrent republish that moves a version yields a 409 ([DecideRejection.CHALLENGE_REUSED]).
     * @param subjectId optional subject id, for policies that use subject attributes.
     * @param accountId optional tenant hint.
     * @return the engine's [DecisionSet] — one [PolicyDecision] per policy. Its
     *   [DecisionSet.claimedArea] is the area the device disclosed in the check's one
     *   area proof (never coordinates), or null when no area proof was submitted.
     * @throws PolicyException fail-closed on an invalid policy set, an
     *   untrusted/unfetchable bundle, an unsupported plan, no provable proof, or a
     *   refused/failed request.
     */
    suspend fun decideMany(
        license: LicenseStatus,
        policies: List<String>,
        subjectId: String? = null,
        accountId: String? = null,
    ): DecisionSet {
        val names = normalizePolicies(policies)
        val licenseId = license.licenseId?.takeIf { it.isNotEmpty() }
            ?: throw PolicyException.LicenseIdUnavailable
        val fetchUrl = license.policyBundleFetchUrl ?: throw PolicyException.NotProvisioned
        val engine = engineOrigin(fetchUrl) ?: throw PolicyException.NotProvisioned
        val trustRoots = license.policyTrustRoots.map { toTrustRoot(it) }

        // The area the check's one area proof claims, read off the proof as it is minted.
        var claimedArea: ClaimedArea? = null
        val set = runDecideMany(engine, names, licenseId, subjectId, accountId, post,
            env = challengeEnvOf(license)) { nonce ->
            // Fetch + verify each policy's bundle fresh (fail-closed), read its plan,
            // and merge: the merged plan is what the whole check proves against. The
            // in-request decide path is online by definition, so this path does not use
            // the offline bundle cache (that backs `evaluate`).
            val plans = names.map { name ->
                val json = fetch(bundleUrlFor(fetchUrl, name))
                val status = verifyBundle(json, trustRoots, null)
                if (status != BundleStatus.VALID) throw PolicyException.BundleRejected(rejection(status))
                readPlan(json)
            }
            val proofs = proveFromPlan(mergePlans(plans), sessionNonceBytes(nonce))
            val submitted = proofs.mapNotNull { it.proofBytesBase64Url }
            if (submitted.isEmpty()) {
                throw PolicyException.NoProofProduced(proofs.map {
                    "${it.canonical}: ${it.verdict.reason} — ${it.verdict.message}"
                })
            }
            claimedArea = claimedAreaOf(proofs)
            submitted
        }
        return set.copy(claimedArea = claimedArea)
    }

    /**
     * Prove every region [bundleJson] requires, bound to [nonceBytes], without
     * uploading. Shared by [prove] and [decide].
     */
    private suspend fun proveRequired(bundleJson: String, nonceBytes: ByteArray): List<PolicyProof> =
        proveFromPlan(readPlan(bundleJson), nonceBytes)

    /**
     * Mint the proofs a (possibly merged) [plan] calls for, bound to [nonceBytes]:
     * one area proof at its `level` (skipped when NONE) plus one disc-verdict proof
     * per shape — all from the same fix. Shared by the single-policy [proveRequired]
     * and the multi-policy [decideMany] (which proves from the merged plan).
     *
     * sessionNonce binds each proof to the decision; no decisionRef ⇒ the bytes are
     * returned in-process for `/v1/decide`.
     */
    private suspend fun proveFromPlan(plan: ProofPlan, nonceBytes: ByteArray): List<PolicyProof> {
        val proofs = mutableListOf<PolicyProof>()

        // One area proof, unbound. A missing area proof (regionUnresolved /
        // insufficientPrecision) is not fatal here — the engine treats named-place
        // conditions as unknown — so record the verdict (no bytes) and continue.
        areaLevel(plan.level)?.let { level ->
            val verdict = sdk.loc.proveArea(level = level, sessionNonce = nonceBytes, decisionRef = null)
            proofs += PolicyProof("area:${plan.level}", verdict, verdict.proof?.proofBytes)
        }

        // One disc-verdict proof per shape, bound to the disc.
        for (shape in plan.shapes) {
            val disc = shape.region as? ShapeRegion.Disc ?: continue
            val verdict = sdk.loc.proveDiscVerdict(
                center = LatLon(disc.lat, disc.lon), radiusMeters = disc.radiusM,
                sessionNonce = nonceBytes, decisionRef = null)
            // Never submit an unbound disc: when semantic-binding v3 isn't armed the SDK
            // returns NOT_YET_RELEASED with no proof. An unbound disc would read as a
            // second area proof and the engine would drop the whole check — so fail closed.
            if (verdict.reason == OctetVerdict.ReasonCode.NOT_YET_RELEASED) {
                throw PolicyException.BindingUnavailable
            }
            proofs += PolicyProof(
                "disc:${disc.lat},${disc.lon},${disc.radiusM}", verdict, verdict.proof?.proofBytes)
        }
        return proofs
    }

    /**
     * Fetch the current bundle, verify it against the license's trust roots with
     * the cached version as the downgrade anchor, and adopt it when `VALID`. On any
     * failure (unreachable, bad signature, malformed, or a downgrade), fall back to
     * the last-known-`VALID` cached bundle; with no such cache, fail closed. The cache
     * counts only if it came from this licence's bundle URL and still verifies
     * against the current trust roots ([usableCache]), so a rotated key, another
     * licence's bundle, or a store tampered with is never served.
     */
    private suspend fun resolveActiveBundle(license: LicenseStatus): ActiveBundle {
        val url = license.policyBundleFetchUrl ?: throw PolicyException.NotProvisioned
        // Empty trust roots ⇒ nothing can verify ⇒ the core returns a non-VALID
        // status ⇒ fail-closed below (never adopts an unverifiable bundle).
        val trustRoots = license.policyTrustRoots.map { toTrustRoot(it) }
        val cached = usableCache(cache.current(), url) {
            verifyBundle(it, trustRoots, null) == BundleStatus.VALID
        }

        // Fetch (a transport failure is recoverable if we hold a cached bundle).
        var freshJson: String? = null
        var fetchError: Exception? = null
        try {
            freshJson = fetch(url)
        } catch (e: PolicyException) {
            fetchError = e
        } catch (e: Exception) {
            fetchError = PolicyException.BundleFetchFailed(e.message ?: e.toString())
        }

        // Verify the fresh bundle, anchored to the cached version (downgrade guard).
        val freshStatus: BundleStatus? = freshJson?.let { verifyBundle(it, trustRoots, cached?.version) }

        return when (resolve(freshStatus, cached != null)) {
            BundleResolution.ADOPT_FRESH -> {
                val json = freshJson!!
                // Carry the anchor forward if the fresh bundle's version can't be
                // read, so a VALID-but-unreadable bundle never regresses the anchor.
                val version = bundleVersion(json) ?: cached?.version
                cache.adopt(PolicyBundleRecord(json, version, url))
                ActiveBundle(json, BundleSource.FRESH)
            }
            BundleResolution.KEEP_CACHED -> ActiveBundle(cached!!.json, BundleSource.CACHED)
            BundleResolution.REJECT_FRESH -> throw PolicyException.BundleRejected(rejection(freshStatus!!))
            BundleResolution.FETCH_FAILED -> throw (fetchError ?: PolicyException.BundleFetchFailed("unreachable"))
        }
    }

    internal companion object {

        /**
         * Pure refresh decision — kept side-effect-free so the fail-closed/fallback
         * policy is unit-testable without the network or the native core.
         *
         * - [BundleResolution.ADOPT_FRESH] when the fresh bundle verified `VALID`.
         * - [BundleResolution.KEEP_CACHED] when it didn't (or wasn't fetched) but a
         *   trusted cache exists.
         * - [BundleResolution.REJECT_FRESH] when it verified non-`VALID` and there
         *   is no cache.
         * - [BundleResolution.FETCH_FAILED] when it wasn't fetched at all and there
         *   is no cache.
         */
        /**
         * The cached record, if Magistrate may use it for [bundleUrl]: it came from
         * that URL and its bundle still verifies ([verifies], the real core in
         * production). Otherwise null — neither a fallback nor a downgrade anchor.
         * Pure, so testable without the native core.
         */
        internal fun usableCache(
            record: PolicyBundleRecord?,
            bundleUrl: String,
            verifies: (String) -> Boolean,
        ): PolicyBundleRecord? =
            record?.takeIf { it.sourceUrl == bundleUrl && verifies(it.json) }

        internal fun resolve(freshStatus: BundleStatus?, hasCached: Boolean): BundleResolution = when {
            freshStatus == BundleStatus.VALID -> BundleResolution.ADOPT_FRESH
            hasCached -> BundleResolution.KEEP_CACHED
            freshStatus != null -> BundleResolution.REJECT_FRESH
            else -> BundleResolution.FETCH_FAILED
        }

        /**
         * Map a [PolicyTrustRoot] (base64url-encoded key) to the magistrate
         * core's [TrustRoot] (raw bytes). Rejects anything but a 32-byte Ed25519
         * key.
         */
        internal fun toTrustRoot(r: PolicyTrustRoot): TrustRoot {
            val key = if (r.alg == "Ed25519") base64UrlDecode(r.publicKey) else null
            if (key == null || key.size != 32) throw PolicyException.MalformedTrustRoot(r.kid)
            return TrustRoot(r.kid, key)
        }

        /**
         * Read the signed proof plan, mapping the reader's [SlimError] fail-closed: an
         * unknown plan version / shape kind / content format → UNSUPPORTED_PLAN
         * ("update Magistrate / republish"); anything else malformed → MALFORMED. Call
         * `verifyBundle` first (as `resolveActiveBundle` does) — `proofPlan` does not
         * check the signature.
         */
        internal fun readPlan(bundleJson: String): ProofPlan = try {
            proofPlan(bundleJson)
        } catch (e: SlimException.Unsupported) {
            throw PolicyException.BundleRejected(BundleRejection.UNSUPPORTED_PLAN)
        } catch (e: SlimException.Malformed) {
            throw PolicyException.BundleRejected(BundleRejection.MALFORMED)
        }

        /** The area proof's level, or null for a shapes-only (NONE) plan (no area proof). */
        internal fun areaLevel(level: PlanLevel): com.octetproof.sdk.api.OctetAreaLevel? =
            when (level) {
                PlanLevel.NONE -> null
                PlanLevel.COUNTRY -> com.octetproof.sdk.api.OctetAreaLevel.COUNTRY
                PlanLevel.SUBDIVISION -> com.octetproof.sdk.api.OctetAreaLevel.SUBDIVISION
            }

        /**
         * The area the submitted area proof claims: the `area:` entry of [proofs] that
         * carries proof bytes, mapped by [claimedAreaOf] (region). Null when there is no
         * such proof (shapes-only plan, or the area couldn't be proven).
         */
        internal fun claimedAreaOf(proofs: List<PolicyProof>): ClaimedArea? {
            val area = proofs.firstOrNull { it.canonical.startsWith("area:") } ?: return null
            if (area.proofBytes == null) return null
            return claimedAreaOf(area.verdict.proof?.claimedRegion ?: return null)
        }

        /**
         * Map a proof's `claimedRegion` to Magistrate's [ClaimedArea], verbatim. Only a
         * country, a subdivision or Earth is an area claim; anything else (an area proof
         * never carries one), or a country/subdivision with an empty code, is null —
         * never a guessed value.
         */
        internal fun claimedAreaOf(region: ProofRegion): ClaimedArea? = when (region) {
            is ProofRegion.Earth -> ClaimedArea(ClaimedArea.Level.EARTH, null)
            is ProofRegion.Country ->
                region.isoCode.takeIf { it.isNotEmpty() }?.let { ClaimedArea(ClaimedArea.Level.COUNTRY, it) }
            is ProofRegion.Subdivision ->
                region.isoCode.takeIf { it.isNotEmpty() }?.let { ClaimedArea(ClaimedArea.Level.SUBDIVISION, it) }
            is ProofRegion.City, is ProofRegion.Ellipse, is ProofRegion.H3PolygonSet,
            is ProofRegion.BoundingBox3D -> null
        }

        internal fun rejection(status: BundleStatus): BundleRejection = when (status) {
            BundleStatus.BAD_SIGNATURE -> BundleRejection.BAD_SIGNATURE
            BundleStatus.MALFORMED -> BundleRejection.MALFORMED
            BundleStatus.STALE -> BundleRejection.STALE
            BundleStatus.VALID -> BundleRejection.MALFORMED // unreachable: caller guards VALID
        }

        /**
         * Read a bundle's monotonic version from `content.version` (u64) — the field
         * verifyBundle's downgrade guard compares against activeVersion
         * (magistrate core opl-ffi/src/lib.rs). Cached and passed back on the next
         * refresh to reject a downgrade as STALE. Null when absent or not a
         * non-negative integer; the bundle is already verified when this is read, so
         * a missing version just leaves the anchor un-advanced.
         */
        internal fun bundleVersionFromContent(json: String): ULong? = try {
            Json.parseToJsonElement(json).jsonObject["content"]
                ?.jsonObject?.get("version")
                ?.jsonPrimitive?.content
                ?.toULongOrNull()
        } catch (e: Exception) {
            null
        }

        /**
         * The session-binding nonce bytes: the challenge nonce STRING's UTF-8 bytes,
         * verbatim (NOT base64url-decoded — the engine binds `nonce.as_bytes()`).
         * Enforces the session-binding bounds (1…512 B).
         */
        internal fun sessionNonceBytes(nonce: String): ByteArray {
            val bytes = nonce.toByteArray(Charsets.UTF_8)
            if (bytes.isEmpty() || bytes.size > 512) throw PolicyException.InvalidNonce
            return bytes
        }

        /** Decode unpadded (or padded) base64url into raw bytes; null on invalid input. */
        internal fun base64UrlDecode(s: String): ByteArray? = try {
            // java.util.Base64's URL decoder tolerates missing padding.
            Base64.getUrlDecoder().decode(s)
        } catch (e: IllegalArgumentException) {
            null
        }

        // --- Decide (in-request path, E1b) ---------------------------------------

        internal fun challengeEnvOf(license: LicenseStatus): String? =
            if (license.isSandbox) "sandbox" else null

        /**
         * The decide handshake, free of [OctetSdk] so it is unit-testable: challenge
         * → `prove(nonce)` → decide. [prove] returns the `proof_bytes_b64` strings of
         * the regions that could be proven.
         */
        internal suspend fun runDecide(
            engine: String,
            policy: String,
            licenseId: String,
            subjectId: String?,
            accountId: String?,
            post: suspend (String, String) -> Pair<Int, String>,
            env: String? = null,
            prove: suspend (String) -> List<String>,
        ): DecisionResult {
            val challenge = postJson(post, "$engine/v1/decide/challenge", buildJsonObject {
                put("policy", policy)
                accountId?.let { put("account_id", it) }
                // A sandbox-token SDK uploads its proofs as sandbox, so the engine must
                // read them there. Absent means prod. The decide carries `license_id`,
                // which the engine requires for sandbox.
                env?.let { put("env", it) }
            }.toString())
            val decisionRef = challenge.string("decision_ref")
            val nonce = challenge.string("nonce")

            val proofs = prove(nonce)
            // Never send an empty set: the engine reads `proofs: []` as the
            // server-fetched path, which this call is not.
            if (proofs.isEmpty()) throw PolicyException.NoProofProduced(emptyList())

            val response = postJson(post, "$engine/v1/decide", buildJsonObject {
                put("policy", policy)
                put("license_id", licenseId)
                put("decision_ref", decisionRef)
                put("proofs", buildJsonArray {
                    proofs.forEach { add(buildJsonObject { put("proof_bytes_b64", it) }) }
                })
                subjectId?.let { put("subject_id", it) }
                accountId?.let { put("account_id", it) }
            }.toString())
            return DecisionResult(
                decision = response.string("decision"),
                obligations = obligationsFromDecideResponse(response),
                reasons = (response["reasons"] as? JsonArray)
                    ?.map { (it as? JsonPrimitive)?.content ?: it.toString() } ?: emptyList(),
                policyVersion = response.string("policy_version").toULongOrNull()
                    ?: throw PolicyException.DecideFailed("unreadable policy_version"),
                proofRoot = response.string("proof_root"),
                decisionRef = decisionRef,
                receipt = (response["receipt"] as? JsonPrimitive)
                    ?.takeIf { it.isString }?.content,
                cause = response.optString("cause"),
                env = response.optString("env"),
            )
        }

        /**
         * The multi-policy decide handshake (proof model v2), free of [OctetSdk] so it
         * is unit-testable: `challenge(policies)` → `prove(nonce)` → `decide`. Both the
         * challenge and the decide carry the policy **names** (the same set, any order);
         * the engine recorded each policy's active version at challenge time and rejects
         * a set/version drift with a 409. [prove] returns the unlabelled
         * `proof_bytes_b64` strings.
         */
        internal suspend fun runDecideMany(
            engine: String,
            policies: List<String>,
            licenseId: String,
            subjectId: String?,
            accountId: String?,
            post: suspend (String, String) -> Pair<Int, String>,
            env: String? = null,
            prove: suspend (String) -> List<String>,
        ): DecisionSet {
            val policiesJson = buildJsonArray { policies.forEach { add(JsonPrimitive(it)) } }
            val challenge = postJson(post, "$engine/v1/decide/challenge", buildJsonObject {
                put("policies", policiesJson)
                accountId?.let { put("account_id", it) }
                env?.let { put("env", it) }
            }.toString())
            val decisionRef = challenge.string("decision_ref")
            val nonce = challenge.string("nonce")

            val proofs = prove(nonce)
            // Never send an empty set: the engine reads `proofs: []` as the
            // server-fetched path, which this call is not.
            if (proofs.isEmpty()) throw PolicyException.NoProofProduced(emptyList())

            val response = postJson(post, "$engine/v1/decide", buildJsonObject {
                // Names only — the same set the challenge recorded; the engine compares
                // the recorded versions itself (a drift ⇒ 409).
                put("policies", policiesJson)
                put("license_id", licenseId)
                put("decision_ref", decisionRef)
                put("proofs", buildJsonArray {
                    proofs.forEach { add(buildJsonObject { put("proof_bytes_b64", it) }) }
                })
                subjectId?.let { put("subject_id", it) }
                accountId?.let { put("account_id", it) }
            }.toString())

            val results = response["results"] as? JsonArray
                ?: throw PolicyException.DecideFailed("decide response missing results")
            return DecisionSet(
                decisionRef = (response["decision_ref"] as? JsonPrimitive)?.content ?: decisionRef,
                results = results.map { policyDecision(it) },
            )
        }

        /**
         * Parse one `results[]` entry of a multi-policy `/v1/decide` response:
         * `{policy, seq, decision, obligations, reasons, policy_version, proof_root,
         * receipt, cause, env}`. Fails closed on a missing required field.
         */
        internal fun policyDecision(raw: JsonElement): PolicyDecision {
            val obj = raw as? JsonObject
                ?: throw PolicyException.DecideFailed("decide result is not an object")
            return PolicyDecision(
                policy = obj.string("policy"),
                seq = obj.string("seq").toIntOrNull()
                    ?: throw PolicyException.DecideFailed("unreadable seq"),
                decision = obj.string("decision"),
                obligations = obligationsFromDecideResponse(obj),
                reasons = (obj["reasons"] as? JsonArray)
                    ?.map { (it as? JsonPrimitive)?.content ?: it.toString() } ?: emptyList(),
                policyVersion = obj.string("policy_version").toULongOrNull()
                    ?: throw PolicyException.DecideFailed("unreadable policy_version"),
                proofRoot = obj.string("proof_root"),
                receipt = (obj["receipt"] as? JsonPrimitive)?.takeIf { it.isString }?.content,
                cause = obj.optString("cause"),
                env = obj.optString("env"),
            )
        }

        /**
         * Trim + drop blank names, then enforce the engine's per-check bound of 1…16
         * policies. Throws [PolicyException.InvalidPolicySet] (reporting the requested
         * count) otherwise.
         */
        internal fun normalizePolicies(policies: List<String>): List<String> {
            val names = policies.map { it.trim() }.filter { it.isNotEmpty() }
            if (names.isEmpty() || names.size > 16) throw PolicyException.InvalidPolicySet(policies.size)
            return names
        }

        /**
         * The bundle-fetch URL for [policy]: [fetchUrl] with its `policy` query
         * parameter set to [policy] (any existing one replaced), every other part of
         * the URL preserved. One engine serves every policy's bundle at
         * `GET /v1/bundle?policy=…`.
         */
        internal fun bundleUrlFor(fetchUrl: String, policy: String): String {
            val enc = java.net.URLEncoder.encode(policy, "UTF-8")
            val parts = fetchUrl.split("?", limit = 2)
            val base = parts[0]
            val kept = parts.getOrNull(1)
                ?.split("&")
                ?.filter { it.isNotEmpty() && !it.startsWith("policy=") }
                ?: emptyList()
            return "$base?" + (kept + "policy=$enc").joinToString("&")
        }

        /**
         * The `obligations` of a `/v1/decide` response. Absent ⇒ none. Present but
         * not an array ⇒ [PolicyException.DecideFailed]: the obligations can't be
         * known, so neither can what the decision requires.
         */
        internal fun obligationsFromDecideResponse(response: Map<String, JsonElement>): List<PolicyObligation> {
            val raw = response["obligations"]
            if (raw == null || raw is JsonNull) return emptyList()
            val list = raw as? JsonArray ?: throw PolicyException.DecideFailed("unreadable obligations")
            return list.map { obligation(it) }
        }

        /**
         * Map one obligation in the engine's externally-tagged form
         * (`"StepUpAuth"`, `{"Log":{"channel":…}}`, `{"Ttl":{"duration":{"ms":…}}}`,
         * …). Anything unrecognised or malformed becomes [PolicyObligation.Unknown]
         * — never dropped.
         */
        internal fun obligation(raw: JsonElement): PolicyObligation {
            if (raw is JsonPrimitive && raw.isString && raw.content == "StepUpAuth") return PolicyObligation.StepUpAuth
            val entry = (raw as? JsonObject)?.entries?.singleOrNull()
            val fields = entry?.value as? JsonObject
            if (entry != null && fields != null) {
                fun str(key: String) = (fields[key] as? JsonPrimitive)?.takeIf { it.isString }?.content
                when (entry.key) {
                    "Log" -> str("channel")?.let { return PolicyObligation.Log(it) }
                    "Degrade" -> str("capability")?.let { return PolicyObligation.Degrade(it) }
                    "Ttl" -> ((fields["duration"] as? JsonObject)?.get("ms") as? JsonPrimitive)
                        ?.takeUnless { it.isString }?.content?.toULongOrNull()
                        ?.let { return PolicyObligation.Ttl(it) }
                    "Custom" -> {
                        val name = str("name")
                        val args = (fields["args"] as? JsonArray)?.map {
                            (it as? JsonPrimitive)?.takeIf { p -> p.isString }?.content
                        }
                        if (name != null && args != null && args.all { it != null }) {
                            return PolicyObligation.Custom(name, args.filterNotNull())
                        }
                    }
                }
            }
            return PolicyObligation.Unknown(sortedKeys(raw).toString())
        }

        /** [e] with object keys sorted, so the raw form matches what iOS reports. */
        private fun sortedKeys(e: JsonElement): JsonElement = when (e) {
            is JsonObject -> JsonObject(e.toSortedMap().mapValues { sortedKeys(it.value) })
            is JsonArray -> JsonArray(e.map { sortedKeys(it) })
            else -> e
        }

        /**
         * POST [body] as JSON and parse a 2xx response object; map the policy
         * service's documented 4xx errors to [DecideRejection], anything else to
         * [PolicyException.DecideFailed].
         */
        private suspend fun postJson(
            post: suspend (String, String) -> Pair<Int, String>,
            url: String,
            body: String,
        ): Map<String, JsonElement> {
            val (status, text) = try {
                post(url, body)
            } catch (e: PolicyException) {
                throw e
            } catch (e: Exception) {
                throw PolicyException.DecideFailed(e.message ?: e.toString())
            }
            if (status !in 200..299) {
                val detail = errorDetail(text)
                val rejection = decideRejection(status)
                    ?: throw PolicyException.DecideFailed("HTTP $status: $detail")
                throw PolicyException.DecideRejected(rejection, detail)
            }
            return try {
                Json.parseToJsonElement(text).jsonObject
            } catch (e: Exception) {
                throw PolicyException.DecideFailed("unreadable response from $url")
            }
        }

        /** A required string/number field, or [PolicyException.DecideFailed]. */
        private fun Map<String, JsonElement>.string(key: String): String =
            (this[key] as? JsonPrimitive)?.takeUnless { it is JsonNull }?.content
                ?: throw PolicyException.DecideFailed("response missing $key")

        /** An optional string field: null when absent, null or not a string. */
        private fun Map<String, JsonElement>.optString(key: String): String? =
            (this[key] as? JsonPrimitive)?.takeIf { it.isString }?.content

        internal fun decideRejection(status: Int): DecideRejection? = when (status) {
            400 -> DecideRejection.BAD_REQUEST
            401 -> DecideRejection.CHALLENGE_UNKNOWN_OR_EXPIRED
            409 -> DecideRejection.CHALLENGE_REUSED
            422 -> DecideRejection.POLICY_SCOPE_MISMATCH
            else -> null
        }

        /** The service's `{"error": "…"}` message, else the (truncated) raw body. */
        internal fun errorDetail(text: String): String = try {
            Json.parseToJsonElement(text).jsonObject["error"]?.jsonPrimitive?.content
        } catch (e: Exception) {
            null
        } ?: text.take(200)

        /**
         * The policy service's base URL: the origin (scheme, host, port) of the
         * bundle fetch URL — one engine serves `/v1/bundle` and `/v1/decide*`.
         */
        internal fun engineOrigin(fetchUrl: String): String? = try {
            val u = java.net.URI(fetchUrl)
            if (u.scheme == null || u.host.isNullOrEmpty()) null
            else "${u.scheme}://${u.host}" + (if (u.port != -1) ":${u.port}" else "")
        } catch (e: Exception) {
            null
        }

        /**
         * The policy name from a verified bundle (`content.policy.name`) — the
         * `policy` the policy service expects on the challenge and the decision.
         */
        internal fun policyNameFromBundle(json: String): String? = try {
            Json.parseToJsonElement(json).jsonObject["content"]
                ?.jsonObject?.get("policy")
                ?.jsonObject?.get("name")
                ?.jsonPrimitive?.content
                ?.takeIf { it.isNotEmpty() }
        } catch (e: Exception) {
            null
        }

        // --- Transport ---------------------------------------------------------
        //
        // Engine calls go through OctetSdk.sendServiceRequest, so they follow the
        // integrator's TransportPolicy — gateway modes, pins, fallbackToDirect —
        // exactly like the SDK's own traffic, instead of going straight to the engine.

        internal fun servicePost(sdk: OctetSdk): suspend (String, String) -> Pair<Int, String> = { url, body ->
            val r = try {
                sdk.sendServiceRequest(OctetServiceRequest(
                    OctetServiceRequest.Method.POST, url,
                    mapOf("Content-Type" to "application/json"), body.toByteArray(Charsets.UTF_8)))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                throw PolicyException.DecideFailed(e.message ?: e.toString())
            }
            r.status to String(r.body, Charsets.UTF_8)
        }

        internal fun serviceFetch(sdk: OctetSdk): suspend (String) -> String = { url ->
            val r = try {
                sdk.sendServiceRequest(OctetServiceRequest(OctetServiceRequest.Method.GET, url))
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                throw PolicyException.BundleFetchFailed(e.message ?: e.toString())
            }
            if (r.status !in 200..299) throw PolicyException.BundleFetchFailed("HTTP ${r.status}")
            String(r.body, Charsets.UTF_8)
        }
    }
}

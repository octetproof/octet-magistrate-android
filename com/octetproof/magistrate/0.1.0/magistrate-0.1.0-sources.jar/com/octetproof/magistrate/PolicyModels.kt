// magistrate/PolicyModels.kt
// Public result + error types for the Magistrate facade.
//
// These deliberately do NOT expose magistrate (uniffi.opl_ffi) types: a consumer
// of Magistrate depends only on :sdk + this module. The magistrate core is an
// implementation detail behind this seam, so its wire types can evolve without
// breaking Magistrate's public surface.
package com.octetproof.magistrate

import com.octetproof.sdk.api.OctetRegion
import com.octetproof.sdk.api.OctetVerdict
import java.util.Base64

/**
 * The verdict for one region a verified bundle requires the device to prove.
 *
 * @property canonical the bundle's canonical region string, verbatim from the
 *   signed bundle (e.g. `"country:US"`, `"subdivision:US-CA"`). Correlates this
 *   result back to the policy that required it.
 * @property region the base-SDK region the predicate was evaluated against.
 * @property verdict the verdict from `isWithin(region, decisionRef = …)` — the
 *   same decision-bound proof any host would mint for this region.
 */
data class PolicyRegionResult(
    val canonical: String,
    val region: OctetRegion,
    val verdict: OctetVerdict,
)

/**
 * The outcome of [Magistrate.evaluate]: one [PolicyRegionResult] per region the
 * verified bundle requires. The bundle backing this evaluation is always trusted
 * (`VALID` when freshly fetched, or a previously-`VALID` cached bundle) — an
 * untrusted bundle with no trusted fallback throws before any region is evaluated
 * (fail-closed).
 *
 * @property servedFromCache `true` when the fresh fetch/verify failed and
 *   evaluation fell back to the last-known-`VALID` cached bundle. The regions are
 *   still trusted, but the policy may be stale — a host can surface this or retry.
 */
data class PolicyEvaluation(
    val regions: List<PolicyRegionResult>,
    val servedFromCache: Boolean = false,
)

/**
 * A persisted policy-bundle record: the last-known-`VALID` bundle JSON, its
 * monotonic version (the downgrade anchor), and the bundle URL it was fetched
 * from. Magistrate uses a record only for that same URL, and only while its bundle
 * still verifies against the licence's current trust roots.
 *
 * @property sourceUrl the licence's bundle URL the bundle came from. A record
 *   without one (written before this field existed) is never used.
 */
data class PolicyBundleRecord(
    val json: String,
    val version: ULong?,
    val sourceUrl: String? = null,
)

/**
 * Cross-launch persistence for the last-`VALID` bundle + its version anchor.
 *
 * By default [Magistrate] caches only in memory (per-instance). Pass a store to
 * `Magistrate(sdk, persistentStore)` — e.g. [EncryptedPrefsPolicyBundleStore] —
 * to survive relaunch.
 *
 * Implementations MUST use a rollback-resistant store (the platform secure
 * storage): the persisted [PolicyBundleRecord.version] is the downgrade anchor, so
 * an attacker who can roll it back could replay an older validly-signed bundle.
 */
interface PolicyBundleStore {
    fun load(): PolicyBundleRecord?
    fun save(record: PolicyBundleRecord)
}

/**
 * One region's on-device proof for the in-request `POST /v1/decide` path (E1b): the
 * signed LocationProof envelope bound to the decision's challenge nonce.
 *
 * A plain class (not a data class) on purpose: [proofBytes] is a ByteArray, whose
 * value semantics don't fit data-class equals/hashCode.
 *
 * @property canonical the bundle's canonical region string this proof answers.
 * @property verdict the `isWithin` verdict for this region (bound to the nonce).
 * @property proofBytes the signed LocationProof envelope bytes — the same bytes
 *   uploaded on the server-fetched path; null when the region couldn't be proven
 *   (`verdict.result == INDETERMINATE`), whereupon the engine denies for missing
 *   coverage.
 */
class PolicyProof(
    val canonical: String,
    val verdict: OctetVerdict,
    val proofBytes: ByteArray?,
) {
    /**
     * [proofBytes] as unpadded URL-safe base64 — the exact `proof_bytes_b64` the
     * policy service's `POST /v1/decide` expects. Null when there is no proof.
     */
    val proofBytesBase64Url: String?
        get() = proofBytes?.let { Base64.getUrlEncoder().withoutPadding().encodeToString(it) }
}

/**
 * The policy service's decision from [Magistrate.decide] — server-authoritative:
 * the engine ran the verifier over the submitted proofs and evaluated the policy.
 *
 * @property decision the engine's decision, verbatim (e.g. `"permit"`, `"deny"`).
 * @property obligations what the host must do when enforcing this decision. **A
 *   permit with obligations is only a permit once the host has fulfilled every one
 *   of them.** The SDK surfaces obligations verbatim; it never enforces them. The
 *   engine returns them as authored, so a set can conflict (e.g. two TTLs).
 * @property reasons the engine's reasons for the decision (diagnostic).
 * @property policyVersion the version of the policy bundle the engine decided against.
 * @property proofRoot the engine's audit commitment for this decision.
 * @property decisionRef the decision's correlation id, from the engine's challenge.
 * @property receipt the engine's signed decision receipt (compact JWS,
 *   EdDSA), verbatim — null when the engine didn't return one. The SDK does
 *   NOT verify it: forward it to your backend, which verifies it against the
 *   engine's `/.well-known/decision-receipt-jwks.json` instead of trusting the device.
 * @property claimedArea the area the device claimed in the area proof it submitted
 *   for this check — what the phone disclosed, never coordinates. Read on the device
 *   from the proof Magistrate generated, not from the engine's response. Null when no
 *   area proof was submitted (the plan asks for none, or the area couldn't be proven).
 * @property cause why the location couldn't be decided, verbatim from the engine:
 *   `absence`, `stale`, `authenticity`, `unbound`, `inconsistent`, `undecidable` or
 *   `other` (later engines may add values). Null when the location was decided. A
 *   cause means the policy question's answer is UNKNOWN: the decision is the policy's
 *   fail-closed `on_indeterminate`, not a reading of where the device is.
 * @property env the proof environment the decision's proofs came from, verbatim
 *   (`release` or `sandbox`). A production backend accepts only `release`. Null when the
 *   engine didn't say (engines before `env`).
 */
data class DecisionResult(
    val decision: String,
    val obligations: List<PolicyObligation> = emptyList(),
    val reasons: List<String>,
    val policyVersion: ULong,
    val proofRoot: String,
    val decisionRef: String,
    val receipt: String? = null,
    val claimedArea: ClaimedArea? = null,
    val cause: String? = null,
    val env: String? = null,
) {
    /**
     * `true` only when the engine returned `permit`. Anything else — `deny` or a
     * decision this SDK doesn't know — is not a permit (fail-closed).
     */
    val isPermit: Boolean
        get() = decision.lowercase() == "permit"
}

/**
 * One policy's decision inside a multi-policy check (see [Magistrate.decideMany]).
 * The engine decides each policy in the check independently, over the same submitted
 * proofs, and returns one of these per policy in [DecisionSet.results].
 *
 * @property policy the policy name this result is for.
 * @property seq the engine's ordinal of this result within the check (its position
 *   in the recorded challenge set).
 * @property decision the engine's decision, verbatim (e.g. `"permit"`, `"deny"`).
 * @property obligations what the host must do when enforcing this decision (see
 *   [DecisionResult.obligations]).
 * @property reasons the engine's reasons for this policy's decision (diagnostic).
 * @property policyVersion the version of this policy's bundle the engine decided against.
 * @property proofRoot the engine's audit commitment for this policy's decision.
 * @property receipt this policy's signed decision receipt (compact JWS), verbatim —
 *   null when the engine didn't return one; its `check_policies` names every policy in
 *   the check. The SDK does not verify it — forward it to your backend.
 * @property cause why the location couldn't be decided for this policy (see
 *   [DecisionResult.cause]); null when it was decided.
 * @property env the proof environment of the check's proofs (see
 *   [DecisionResult.env]).
 */
data class PolicyDecision(
    val policy: String,
    val seq: Int,
    val decision: String,
    val obligations: List<PolicyObligation> = emptyList(),
    val reasons: List<String>,
    val policyVersion: ULong,
    val proofRoot: String,
    val receipt: String? = null,
    val cause: String? = null,
    val env: String? = null,
) {
    /** `true` only when the engine returned `permit` for this policy (fail-closed). */
    val isPermit: Boolean
        get() = decision.lowercase() == "permit"
}

/**
 * The outcome of [Magistrate.decideMany]: the engine's per-policy decisions for a
 * single multi-policy check, all sharing one [decisionRef] and one set of submitted
 * proofs. Server-authoritative.
 *
 * @property decisionRef the check's correlation id, from the engine's challenge.
 * @property results one [PolicyDecision] per policy in the check, in the engine's order.
 * @property claimedArea the area the device claimed in the one area proof it submitted
 *   for the whole check — what the phone disclosed, never coordinates. Read on the
 *   device from the proof Magistrate generated, not from the engine's response. Null
 *   when no area proof was submitted (the merged plan asks for none, or the area
 *   couldn't be proven).
 */
data class DecisionSet(
    val decisionRef: String,
    val results: List<PolicyDecision>,
    val claimedArea: ClaimedArea? = null,
) {
    /** This check's decision for [policy], or null if the engine returned none. */
    fun forPolicy(policy: String): PolicyDecision? = results.firstOrNull { it.policy == policy }

    /** `true` only when every policy in the check permitted (and the check is non-empty). */
    val allPermit: Boolean
        get() = results.isNotEmpty() && results.all { it.isPermit }
}

/**
 * The area a device claimed in the area proof it sent with a decision: the named place
 * the phone disclosed (a country, a subdivision, or only "on Earth"), never
 * coordinates. It is read from the signed proof Magistrate generated, verbatim.
 *
 * @property level how specific the claim is.
 * @property code the claimed place's ISO code, as the proof carries it: ISO 3166-1
 *   alpha-2 for [Level.COUNTRY] (e.g. `"GB"`), ISO 3166-2 for [Level.SUBDIVISION]
 *   (e.g. `"US-CA"`), null for [Level.EARTH].
 */
data class ClaimedArea(
    val level: Level,
    val code: String?,
) {
    /** How specific the claim is. */
    enum class Level {
        /**
         * The device claimed only that it is on Earth: its accuracy area may cross a
         * border, so it named no country. [code] is null.
         */
        EARTH,

        /** The device claimed a country. [code] is ISO 3166-1 alpha-2 (e.g. `"GB"`). */
        COUNTRY,

        /** The device claimed a subdivision. [code] is ISO 3166-2 (e.g. `"US-CA"`). */
        SUBDIVISION,
    }
}

/** An obligation the host must fulfil when enforcing a decision. */
sealed class PolicyObligation {
    /** Require a step-up authentication before acting on the decision. */
    object StepUpAuth : PolicyObligation() {
        private fun readResolve(): Any = StepUpAuth
        override fun toString() = "StepUpAuth"
    }

    /** Record the decision on the named audit [channel]. */
    data class Log(val channel: String) : PolicyObligation()

    /** Act on the decision only with the named reduced [capability]. */
    data class Degrade(val capability: String) : PolicyObligation()

    /** The decision holds for [durationMs] milliseconds, then must be re-decided. */
    data class Ttl(val durationMs: ULong) : PolicyObligation()

    /** A tenant-defined `x-<name>` obligation, opaque to the engine. */
    data class Custom(val name: String, val args: List<String>) : PolicyObligation()

    /**
     * An obligation this SDK version doesn't recognise (e.g. added by a newer
     * engine), as its raw JSON. Surfaced, never dropped: the host still has to
     * handle it — treat one it can't fulfil as not permitted.
     */
    data class Unknown(val rawJson: String) : PolicyObligation()
}

/** Why the policy service refused a `decide` request (its documented 4xx errors). */
enum class DecideRejection {
    /** 400 — bad request body, bad base64, or a missing `decision_ref`. */
    BAD_REQUEST,

    /** 401 — the challenge is unknown or expired (challenges are short-lived). */
    CHALLENGE_UNKNOWN_OR_EXPIRED,

    /**
     * 409 — the challenge was already used (challenges are single-use), or, on a
     * multi-policy `decide`, the submitted policy set or a policy version differs
     * from the set the challenge recorded (the challenge is then used up).
     */
    CHALLENGE_REUSED,

    /** 422 — the challenge was issued for a different policy. */
    POLICY_SCOPE_MISMATCH,
}

/**
 * Why the magistrate core refused a fetched bundle. Mirrors the core's
 * non-`VALID` `BundleStatus` cases; anything here means "do not trust this
 * bundle."
 */
enum class BundleRejection {
    /** No matching trust root, or the Ed25519 signature didn't verify. */
    BAD_SIGNATURE,

    /** The bundle wasn't well-formed / couldn't be canonicalized. */
    MALFORMED,

    /**
     * Validly signed but older than the device's known active version (the
     * downgrade guard).
     */
    STALE,

    /**
     * The bundle's proof-plan version or shape kind (or its content format) is one
     * this Magistrate build doesn't know — fail closed, "update Magistrate / republish
     * the policy" (maps `SlimError.Unsupported` from `proofPlan`).
     */
    UNSUPPORTED_PLAN,
}

/**
 * Failures surfaced by [Magistrate.evaluate]. The facade guarantees one of these
 * on every failure; it never leaks a raw magistrate or transport exception.
 */
sealed class PolicyException(message: String) : Exception(message) {

    /**
     * The license carries no policy bundle URL — policies aren't provisioned for this
     * licence, so there's nothing to evaluate.
     */
    object NotProvisioned : PolicyException(
        "no policy bundle URL on the license (policies not provisioned)"
    ) {
        private fun readResolve(): Any = NotProvisioned
    }

    /**
     * A trust root couldn't be used: its `alg` wasn't `Ed25519`, or its
     * `publicKey` wasn't unpadded base64url of 32 raw Ed25519 bytes.
     */
    data class MalformedTrustRoot(val kid: String) :
        PolicyException("malformed policy trust root: $kid")

    /**
     * Fetching the bundle from the license's `policyBundleFetchUrl` failed
     * (transport error, non-2xx, or a non-UTF8 body). [detail] is a diagnostic,
     * not for control flow.
     */
    data class BundleFetchFailed(val detail: String) :
        PolicyException("policy bundle fetch failed: $detail")

    /** The magistrate core rejected the bundle. Fail-closed — anything but `VALID`. */
    data class BundleRejected(val rejection: BundleRejection) :
        PolicyException("policy bundle rejected: $rejection")

    /**
     * The verified bundle requires a region shape this SDK can't evaluate yet
     * (v1 supports country / subdivision / disc / earth). Thrown rather than
     * skipped: silently dropping a required region would let a decision pass
     * without proving something the policy demands.
     */
    data class UnsupportedRegion(val canonical: String) :
        PolicyException("unsupported policy region: $canonical")

    /**
     * The challenge nonce passed to `prove` was empty or, as UTF-8, exceeded the
     * 512-byte session-binding cap. The engine's `/v1/decide/challenge` nonce is a
     * short base64url string, so this indicates the wrong value was supplied.
     */
    object InvalidNonce : PolicyException("invalid challenge nonce for session binding") {
        private fun readResolve(): Any = InvalidNonce
    }

    /**
     * `decide` needs the active license's id (`LicenseStatus.licenseId`) and it
     * was null — the SDK hasn't activated yet.
     */
    object LicenseIdUnavailable : PolicyException("no license id on the license status (not activated)") {
        private fun readResolve(): Any = LicenseIdUnavailable
    }

    /**
     * No required region could be proven, so there is nothing to submit. Thrown
     * rather than sending an empty `proofs` set: the engine would treat that as a
     * different (server-fetched) decision path, not this one. [details] has one
     * entry per region — `"<canonical>: <verdict reason> — <verdict message>"` —
     * saying why it produced no proof (e.g. `NO_FIX` while the pipeline warms up).
     */
    data class NoProofProduced(val details: List<String>) :
        PolicyException("no required region could be proven: " + details.joinToString("; "))

    /**
     * [Magistrate.decideMany] was called with an empty policy list or more than the
     * engine's per-check maximum of 16. [count] is the number requested.
     */
    data class InvalidPolicySet(val count: Int) :
        PolicyException("a decide check needs 1…16 policies (got $count)")

    /**
     * The policy service refused the `decide` request. [detail] is the service's
     * diagnostic, not for control flow.
     */
    data class DecideRejected(val rejection: DecideRejection, val detail: String) :
        PolicyException("policy decide rejected: $rejection ($detail)")

    /**
     * The `decide` round-trip failed for another reason (transport error, an
     * unexpected HTTP status, or an unreadable response). Diagnostic only.
     */
    data class DecideFailed(val detail: String) :
        PolicyException("policy decide failed: $detail")

    /**
     * A shape's disc-verdict proof couldn't be bound because semantic-binding v3 isn't
     * armed in this build (the SDK returned NOT_YET_RELEASED). Fail-closed: an unbound
     * disc proof would read as a second area proof and the engine would drop the whole
     * check, so the check is refused instead.
     */
    object BindingUnavailable :
        PolicyException("disc verdict proofs need semantic-binding v3, which is not armed in this build")
}

// magistrate/EncryptedPrefsPolicyBundleStore.kt
// Default rollback-resistant PolicyBundleStore backed by EncryptedSharedPreferences
// (AES-256, master key in the Android Keystore) — the same secure-storage approach
// the base SDK uses for its license cache.
//
// The persisted record's version is the downgrade anchor, so it lives in the
// encrypted store (survives relaunch; not world-readable; resists casual tampering)
// rather than a plain file. A fully rollback-proof anchor (a hardware monotonic
// counter) is a future hardening; this raises the bar to the platform secure store.
// NOTE: install-scoped on Android — EncryptedSharedPreferences resets on reinstall
// (mirrors the base SDK's license cache).
package com.octetproof.magistrate

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class EncryptedPrefsPolicyBundleStore(
    context: Context,
    prefsName: String = "octet_policy_bundle",
) : PolicyBundleStore {

    private val appContext = context.applicationContext

    private val prefs by lazy {
        val masterKey = MasterKey.Builder(appContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            appContext,
            prefsName,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
    }

    override fun load(): PolicyBundleRecord? {
        val json = prefs.getString(KEY_JSON, null) ?: return null
        return PolicyBundleRecord(
            json,
            prefs.getString(KEY_VERSION, null)?.toULongOrNull(),
            prefs.getString(KEY_SOURCE_URL, null),
        )
    }

    override fun save(record: PolicyBundleRecord) {
        prefs.edit().apply {
            putString(KEY_JSON, record.json)
            if (record.version != null) putString(KEY_VERSION, record.version.toString())
            else remove(KEY_VERSION)
            if (record.sourceUrl != null) putString(KEY_SOURCE_URL, record.sourceUrl)
            else remove(KEY_SOURCE_URL)
            apply()
        }
    }

    private companion object {
        const val KEY_JSON = "json"
        const val KEY_VERSION = "version"
        const val KEY_SOURCE_URL = "source_url"
    }
}
